package com.airplay.webplus.Settings;

import android.os.Bundle;
import android.support.v7.preference.ListPreference;
import android.support.v7.preference.PreferenceFragmentCompat;
import com.airplay.webplus.R;
import com.airplay.webplus.SearchInstance;

public class SettingsFragment extends PreferenceFragmentCompat {
    ListPreference searchEngineSelect;
    SearchInstance instance = new SearchInstance();
    @Override
    public void onCreatePreferences(Bundle bundle, String key) {
        setPreferencesFromResource(R.xml.preference, key);
        String[] searchEngineList = instance.getSearchEngines();
        String[] searchEngineLinkList = instance.getSearchEngineLinks();
        searchEngineSelect = (ListPreference) findPreference("defaultEngine");
        searchEngineSelect.setEntries(searchEngineList);
        searchEngineSelect.setEntryValues(searchEngineLinkList);
    }

}

package com.airplay.webplus;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.airplay.webplus.Settings.Settings;

public class MainActivity extends AppCompatActivity {
    EditText mEditText;
    Toolbar mToolBar;
    String urlEntered;
    WebView mWebView;
    SearchInstance instance = new SearchInstance();
    String recentUrl;
    String selectedEngine;
    LinearLayout mLinearLayout;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mEditText = findViewById(R.id.actionSearch);
        mToolBar = findViewById(R.id.toolBar);
        setSupportActionBar(mToolBar);
        mLinearLayout = findViewById(R.id.linearLayout);
        mWebView = findViewById(R.id.WebView);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        selectedEngine = sharedPreferences.getString("defaultEngine", "https://www.google.com");
        String lastUrl = sharedPreferences.getString("lastUrl", selectedEngine);
        mWebView.requestFocus();
        if (savedInstanceState != null){
            mWebView.restoreState(savedInstanceState);}
        else {
            mWebView.loadUrl(lastUrl);}
//        if (sharedPreferences.getBoolean("firstTime", true)){
//            mWebView.loadUrl(selectedEngine);
//
//            sharedPreferences.edit().putBoolean("firstTime", false)
//                    .commit();
//        }
        mEditText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == event.KEYCODE_ENTER && event.getAction() == event.ACTION_DOWN) {
                    urlEntered = mEditText.getText().toString();
                    mWebView.loadUrl(instance.ProcessSearch(urlEntered, selectedEngine));
                    mWebView.requestFocus();
                }
                return false;
            }
        });
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                displayURL(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
            }
        });

//        detector = new GestureDetector(this, new GestureListener());
//
//        mToolBar.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                return detector.onTouchEvent(event);
//            }
//        });
}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_options, menu);
        return true;
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && mWebView.canGoBack()) {
                mWebView.goBack();
                return true;
            }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.googleHome:
                loadHome();
                break;

            case R.id.menuSettings:
                Intent settingsIntent = new Intent(this, Settings.class);
                startActivity(settingsIntent);
                break;
//
//            case R.id.bookmarkAdd:
//                Set<String> defBookmark = new HashSet<>();
//                defBookmark.add("https://www.google.com");
//                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
//                bookmarks = sharedPreferences.getStringSet("bookmarks", defBookmark);
//                bookmarks.add(mWebView.getUrl());
//                sharedPreferences.edit().putStringSet("bookmarks", bookmarks);
//                break;
//
//            case R.id.displayBookmarks:
//                startActivity(new Intent(this, Bookmarks.class));
//                break;
        }

        return true;
    }

    public void displayURL(String url) {
        mEditText.setText(url);
    }

    public void loadHome() {
        mWebView.loadUrl(PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getString("defaultEngine", "https://www.google.com"));
    }


    @Override
    protected void onPause() {
        super.onPause();
        mWebView.onPause();
    }

    @Override
        protected void onStop() {
        super.onStop();
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        sharedPreferences.edit().putString("lastUrl", mWebView.getUrl())
                .commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mWebView.onResume();
        if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("dataSaving", false))
            mWebView.getSettings().setLoadsImagesAutomatically(false);
        else
            mWebView.getSettings().setLoadsImagesAutomatically(true);
    }
    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        mWebView.saveState(outState);
        super.onSaveInstanceState(outState, outPersistentState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        mWebView.restoreState(savedInstanceState);
    }

    @Override
    protected void onStart() {
        super.onStart();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        boolean choose = sharedPreferences.getBoolean("enableJavaScript", true);

        if (choose)
            mWebView.getSettings().setJavaScriptEnabled(true);
        else
            mWebView.getSettings().setJavaScriptEnabled(false);

    }

//    class GestureListener extends GestureDetector.SimpleOnGestureListener {
//        boolean result;
//
//        @Override
//        public boolean onDown(MotionEvent event) {
//            // don't return false here or else none of the other
//            // gestures will work
//            return true;
//        }
//
//        @Override
//        public boolean onSingleTapConfirmed(MotionEvent e) {
//            return true;
//        }
//
//        @Override
//        public void onLongPress(MotionEvent e) {
//        }
//
//        @Override
//        public boolean onDoubleTap(MotionEvent e) {
//            return true;
//        }
//
//        @Override
//        public boolean onScroll(MotionEvent e1, MotionEvent e2,
//                                float distanceX, float distanceY) {
//            return true;
//        }
//
//        @Override
//        public boolean onFling(MotionEvent event1, MotionEvent event2,
//                               float velocityX, float velocityY) {
//            result = false;
//            if (Math.abs(event2.getY() - event1.getY()) < Math.abs(event2.getX() - event1.getX())) {
//                if ((event2.getX() - event1.getX()) > 0) {
//                    mWebView.goBack();
//                } else {
//                    mWebView.goForward();
//                }
//                result = true;
//            }
//            return result;
//        }
//    }
}
package com.airplay.webplus;

import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.WebView;

import static android.content.ContentValues.TAG;

public class MenuAction extends AppCompatActivity {

    public void SettingsResponse(){
        Log.d(TAG, "Settings is clicked");
    }

    public void OptimizeResponse(){
        Log.d(TAG, "Optimization in process....");
    }

    public void GoogleButtonResponse(WebView mWebView){
        mWebView = findViewById(R.id.WebView);
        mWebView.loadUrl("https://www.google.com");
    }
}
